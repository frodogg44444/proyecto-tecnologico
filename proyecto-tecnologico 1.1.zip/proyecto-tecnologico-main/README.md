pagina web del proyecto para la residencia de estudiantes margarola esto es lo que llevo un trabajo totalmente amateur y sin ensamblar


//////
-registro de cambios 1.1
-se añadio la conexion de la base de datos  se cambio y discutio el como sera mostrada la pagina
s