<?php
// Datos de usuario (en un entorno real, esto debería ser una base de datos)
$valid_username = "usuario";
$valid_password = "contraseña";

// Comprobar si se han enviado los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Verificar las credenciales
    if ($username === $valid_username && $password === $valid_password) {
        echo "¡Bienvenido, " . htmlspecialchars($username) . "!";
    } else {
        echo "Usuario o contraseña incorrectos.";
    }
} else {
    echo "Acceso denegado.";
}
?>