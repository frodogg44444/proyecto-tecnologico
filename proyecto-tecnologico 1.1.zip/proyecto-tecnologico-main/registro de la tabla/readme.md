//como probarlo: 
Crea un archivo llamado crear_base_datos.php y copia el contenido del primer bloque de código en él. Ejecuta este archivo en tu servidor para crear la base de datos y la tabla.
Crea un archivo llamado registro.php y copia el contenido del segundo bloque de código en él.
Crea un archivo llamado procesar_registro.php y copia el contenido del tercer bloque de código en él.
Coloca todos los archivos en un servidor web que soporte PHP (como XAMPP, MAMP, o un servidor web en línea).
Accede a registro.php a través de tu navegador y prueba el formulario de registro.
Notas de Seguridad
Este ejemplo utiliza la función password_hash para hash la contraseña, lo que es una buena práctica de seguridad.
Sin embargo, este ejemplo no utiliza medidas de protección contra ataques como SQL Injection y Cross-Site Scripting (XSS).
Considera usar HTTPS para proteger la información transmitida.
En un entorno real, debes utilizar una contraseña segura para la base de datos y no dejar la contraseña vacía como en este ejemplo.