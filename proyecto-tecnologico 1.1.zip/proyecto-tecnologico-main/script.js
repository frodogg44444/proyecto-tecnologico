<script>
    // Seleccionar todos los enlaces de navegación
    const navLinks = document.querySelectorAll('nav a');

    // Añadir un evento de clic a cada enlace
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); // Evitar el comportamiento predeterminado del enlace

            const targetId = this.getAttribute('href'); // Obtener el ID del destino
            const targetElement = document.querySelector(targetId); // Seleccionar el elemento destino

            // Desplazarse suavemente al elemento destino
            targetElement.scrollIntoView({
                behavior: 'smooth', // Comportamiento de desplazamiento suave
                block: 'start' // Alinear el elemento al inicio de la vista
            });
        });
    });
</script>


const form = document.getElementById('contactForm');
const formResponse = document.getElementById('formResponse');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const sugerencias = document.getElementById('sugerencias').value;
    // Aquí puedes agregar la lógica para enviar el formulario
    formResponse.textContent = `Gracias por tu sugerencia, ${sugerencias}!`;
});